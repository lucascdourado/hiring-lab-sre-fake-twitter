from database import db_session, init_db

if __name__ == "__main__":
    init_db()